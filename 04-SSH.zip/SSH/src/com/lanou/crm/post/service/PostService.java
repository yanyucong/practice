package com.lanou.crm.post.service;

import com.lanou.crm.department.domain.CrmDepartment;
import com.lanou.crm.post.domain.CrmPost;

import java.util.List;

/**
 * Created by zyf on 2018/1/26.
 */
public interface PostService {
	List<CrmPost> findByDep(CrmDepartment department);
}
