package com.lanou.crm.department.web.action;

import com.opensymphony.xwork2.ActionSupport;

/**
 * Created by zyf on 2018/1/24.
 */
public class DepartmentAction extends ActionSupport {




}
