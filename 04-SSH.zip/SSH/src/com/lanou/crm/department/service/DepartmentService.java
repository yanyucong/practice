package com.lanou.crm.department.service;

import com.lanou.crm.department.domain.CrmDepartment;

import java.util.List;

/**
 * Created by zyf on 2018/1/26.
 */
public interface DepartmentService {
	List<CrmDepartment> findAll();
}
