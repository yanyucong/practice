package com.lanou.crm.department.service.impl;

import com.lanou.crm.department.dao.DepartmentDao;
import com.lanou.crm.department.domain.CrmDepartment;
import com.lanou.crm.department.service.DepartmentService;

import java.util.List;

/**
 * Created by zyf on 2018/1/26.
 */
public class DepartmentServiceImpl implements DepartmentService {
	private DepartmentDao departmentDao;


	@Override
	public List<CrmDepartment> findAll() {

		return departmentDao.findAll();
	}

	public void setDepartmentDao(DepartmentDao departmentDao) {
		this.departmentDao = departmentDao;
	}
}
