package com.lanou.crm.department.dao.impl;

import com.lanou.crm.department.dao.DepartmentDao;
import com.lanou.crm.department.domain.CrmDepartment;
import org.springframework.orm.hibernate5.support.HibernateDaoSupport;

import java.util.List;

/**
 * Created by zyf on 2018/1/26.
 */
public class DepartmentDaoImpl extends HibernateDaoSupport implements DepartmentDao {

	@Override
	public List<CrmDepartment> findAll() {
		return (List<CrmDepartment>) this.getHibernateTemplate().find("from CrmDepartment ");
	}
}
