package com.lanou.crm.department.dao;

import com.lanou.crm.department.domain.CrmDepartment;

import java.util.List;

/**
 * Created by zyf on 2018/1/26.
 */
public interface DepartmentDao {

	List<CrmDepartment> findAll();

}
