package com.lanou.crm.staff.web.action;

import com.lanou.crm.department.domain.CrmDepartment;
import com.lanou.crm.department.service.DepartmentService;
import com.lanou.crm.staff.domain.CrmStaff;
import com.lanou.crm.staff.service.StaffService;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;
import com.opensymphony.xwork2.util.ValueStack;

import java.util.List;

/**
 * Created by zyf on 2018/1/24.
 */
public class StaffAction extends ActionSupport implements ModelDriven<CrmStaff>{
	//封装数据
	private CrmStaff staff = new CrmStaff();


	//员工模块业务处理接口
	private StaffService staffService;


	//部门模块业务处理接口
	private DepartmentService departmentService;

	/**
	 * 登录
	 * @return
	 */
	public String login(){
		CrmStaff login = staffService.login(staff);

		if(login != null){
			//将用户数据保存到session中
			ActionContext.getContext().getSession().put("loginStaff",login);

			System.out.println(login.getStaffName());
			//返回成功，在xml中重定向到首页
			return SUCCESS;
		}
		//不成功
		//添加错误信息
		addFieldError("","用户名或密码错误");
		//返回LOGIN，表示登录出现问题，转发到登录页面
		return LOGIN;
	}



	/**
	 * 访问主页
	 * @return
	 */
	public String home(){
		return "home";
	}


	/**
	 * 查询所有员工
	 * @return
	 */
	public String findAll(){
		List<CrmStaff> allStaffs =
				staffService.findAll();
		System.out.println(allStaffs.size());
		ActionContext.getContext().put("allStaffs",allStaffs);
		return "findAll";
	}

	/**
	 * 编辑员工之前，需要先查询该员工信息，显示到form中
	 * 		需要查询所有部门，提供在编辑页面中
	 * @return
	 */
	public String editPre(){
		CrmStaff crmStaff = staffService.findStaffById(this.getModel().getStaffId());


		//放入值栈栈顶，jsp中通过ognl找的时候直接在栈顶就能找到
		ValueStack valueStack = ActionContext.getContext().getValueStack();
		valueStack.push(crmStaff);


		List<CrmDepartment> allDeps = departmentService.findAll();
		//将部门集合放入值栈中
		valueStack.set("allDeps",allDeps);



		System.out.println("hahah");
		return "editPre";
	}

	/**
	 * 编辑员工：更新员工信息
	 * @return
	 */
	public String edit(){
		System.out.println("---action：edit----");
		staffService.updateStaff(staff);
		return "edit";
	}


	@Override
	public CrmStaff getModel() {
		return staff;
	}


	public void setStaffService(StaffService staffService) {
		this.staffService = staffService;
	}

	public void setStaff(CrmStaff staff) {
		this.staff = staff;
	}

	public void setDepartmentService(DepartmentService departmentService) {
		this.departmentService = departmentService;
	}
}
