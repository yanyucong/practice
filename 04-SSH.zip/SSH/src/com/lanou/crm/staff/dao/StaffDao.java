package com.lanou.crm.staff.dao;

import com.lanou.crm.staff.domain.CrmStaff;

import java.util.List;

/**
 * Created by zyf on 2018/1/24.
 */
public interface StaffDao {
	CrmStaff findByLogin(String loginName, String loginPwd);

	List<CrmStaff> findAll();

	CrmStaff findStaffById(String staffId);

	void updateStaff(CrmStaff crmStaff);
}
