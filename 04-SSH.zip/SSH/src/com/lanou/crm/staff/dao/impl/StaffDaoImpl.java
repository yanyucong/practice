package com.lanou.crm.staff.dao.impl;

import com.lanou.crm.staff.dao.StaffDao;
import com.lanou.crm.staff.domain.CrmStaff;
import com.lanou.crm.utils.StringUtils;
import org.springframework.orm.hibernate5.support.HibernateDaoSupport;

import java.util.List;

/**
 * Created by zyf on 2018/1/24.
 */
public class StaffDaoImpl extends HibernateDaoSupport implements StaffDao {
	@Override
	public CrmStaff findByLogin(String loginName, String loginPwd) {
		//sql
		String sql = "from CrmStaff where loginName=? and loginPwd=?";

		List<CrmStaff> allStaffs =
				(List<CrmStaff>) this.getHibernateTemplate().find(sql, loginName, loginPwd);
		this.getHibernateTemplate().execute(session -> {

			return null;
		});
		if(allStaffs.size() == 1){
			return allStaffs.get(0);
		}
		return null;
	}

	@Override
	public List<CrmStaff> findAll() {
		List<CrmStaff> objects = (List<CrmStaff>) this.getHibernateTemplate().find("from CrmStaff ");
		for (CrmStaff object : objects) {
			if(object.getPost() != null){

			System.out.println(object.getPost().getPostName()+"-----"+object.getPost().getCrmDepartment().getDepName());
			}

		}
		return objects;
	}

	@Override
	public CrmStaff findStaffById(String staffId) {
		CrmStaff crmStaff = this.getHibernateTemplate().get(CrmStaff.class, staffId);
		return crmStaff;
	}

	@Override
	public void updateStaff(CrmStaff crmStaff) {
		CrmStaff dbStaff = this.getHibernateTemplate().get(CrmStaff.class, crmStaff.getStaffId());

		System.out.println("员工密码为："+crmStaff.getLoginPwd()+"---"+crmStaff.getStaffName());
		//判断密码是否一致
		if (!dbStaff.getLoginPwd().equals(crmStaff.getLoginPwd())) {
			//表示要更新密码了，将密码加密
			dbStaff.setLoginPwd(StringUtils.getMD5Value(crmStaff.getLoginPwd()));
		}

		dbStaff.setLoginName(crmStaff.getLoginName());
		dbStaff.setStaffName(crmStaff.getStaffName());
		dbStaff.setGender(crmStaff.getGender());
		dbStaff.setPost(crmStaff.getPost());
		dbStaff.setOnDutyDate(crmStaff.getOnDutyDate());


	}
}
