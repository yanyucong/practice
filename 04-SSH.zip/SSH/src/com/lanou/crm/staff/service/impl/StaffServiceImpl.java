package com.lanou.crm.staff.service.impl;

import com.lanou.crm.staff.dao.StaffDao;
import com.lanou.crm.staff.domain.CrmStaff;
import com.lanou.crm.staff.service.StaffService;
import com.lanou.crm.utils.StringUtils;

import java.util.List;

/**
 * Created by zyf on 2018/1/24.
 */
public class StaffServiceImpl implements StaffService{

	private StaffDao staffDao;

	public void setStaffDao(StaffDao staffDao) {
		this.staffDao = staffDao;
	}

	@Override
	public CrmStaff login(CrmStaff crmStaff) {
		//MD5加密
		String loginPwd = StringUtils.getMD5Value(crmStaff.getLoginPwd());
		return staffDao.findByLogin(crmStaff.getLoginName(),loginPwd);
	}

	@Override
	public List<CrmStaff> findAll() {
		return staffDao.findAll();
	}

	@Override
	public CrmStaff findStaffById(String staffId) {

		return staffDao.findStaffById(staffId);
	}

	@Override
	public void updateStaff(CrmStaff crmStaff) {
		System.out.println("---service：update----");

		staffDao.updateStaff(crmStaff);
	}
}
