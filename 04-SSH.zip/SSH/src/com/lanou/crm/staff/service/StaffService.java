package com.lanou.crm.staff.service;

import com.lanou.crm.staff.domain.CrmStaff;

import java.util.List;

/**
 * Created by zyf on 2018/1/24.
 */
public interface StaffService {

	CrmStaff login(CrmStaff crmStaff);

	List<CrmStaff> findAll();

	CrmStaff findStaffById(String staffId);

	void updateStaff(CrmStaff crmStaff);
}
