package com.lanou.crm.base.action;

import com.lanou.crm.course_type.service.CourseTypeService;
import com.lanou.crm.department.service.DepartmentService;
import com.lanou.crm.post.service.PostService;
import com.lanou.crm.staff.service.StaffService;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

/**
 * Created by zyf on 2018/1/26.
 */
public class BaseAction<T> extends ActionSupport implements ServletRequestAware,ServletResponseAware,ModelDriven<T>{
	private HttpServletRequest request;
	private HttpServletResponse response;

	private Class clazz;
	private T t;


	private StaffService staffService;
	private DepartmentService departmentService;
	private PostService postService;
	private CourseTypeService courseTypeService;

	public BaseAction() {
		try {
			//当子类继承了BaseAction后，会执行父类空参数的构造方法
			//当执行这个空参数构造方法时，这个this指的就是子类对象
			//那么子类对象获得直接超类super的泛型参数
			//这个泛型参数，实际上就是我们在创建子类继承BaseAction时，传入的泛型类型
			ParameterizedType type = (ParameterizedType) this.getClass().getGenericSuperclass();

			//从泛型参数中，获得第0位置（因为我们只给了一个泛型参数）
			//赋值到类对象clazz上
			this.clazz = (Class) type.getActualTypeArguments()[0];
			//通过类对象，创建一个该类的对象
			//这步操作，就省去了在每个Action中，都要创建一个实体类对象的过程
			//（这个对象用来装载前端页面给我们提交的参数）
			this.t = (T) this.clazz.newInstance();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	//以下是封装一些方法，方便进行赋值操作

	/**
	 * 给contextmap赋值
	 * @param key
	 * @param value
	 */
	public void put(String key,String value){
		ActionContext.getContext().put(key,value);
	}

	public void toSession(String key,String value){
		ActionContext.getContext().getSession().put(key,value);
	}

	public void toApplication(String key,String value){
		ActionContext.getContext().getApplication().put(key,value);
	}

	/**
	 * 给root值栈设置内容
	 * @param key
	 * @param value
	 */
	public void setToRootStack(String key,Object value){
		ActionContext.getContext().getValueStack().set(key,value);
	}

	/**
	 * 将某个对象，压栈，置于栈顶
	 * @param obj
	 */
	public void putToRootStack(Object obj){
		ActionContext.getContext().getValueStack().push(obj);
	}



	@Override
	public void setServletRequest(HttpServletRequest httpServletRequest) {
		this.request = httpServletRequest;
	}

	@Override
	public void setServletResponse(HttpServletResponse httpServletResponse) {
		this.response = httpServletResponse;
	}

	public HttpServletRequest getRequest() {
		return request;
	}

	public HttpServletResponse getResponse() {
		return response;
	}


	public ServletContext getApplication() {
		return request.getServletContext();
	}


	public HttpSession getSession() {
		return request.getSession();
	}


	public StaffService getStaffService() {
		return staffService;
	}

	public void setStaffService(StaffService staffService) {
		this.staffService = staffService;
	}

	public DepartmentService getDepartmentService() {
		return departmentService;
	}

	public void setDepartmentService(DepartmentService departmentService) {
		this.departmentService = departmentService;
	}

	public PostService getPostService() {
		return postService;
	}

	public void setPostService(PostService postService) {
		this.postService = postService;
	}

	public CourseTypeService getCourseTypeService() {
		return courseTypeService;
	}

	public void setCourseTypeService(CourseTypeService courseTypeService) {
		this.courseTypeService = courseTypeService;
	}

	@Override
	public T getModel() {
		return t;
	}
}
