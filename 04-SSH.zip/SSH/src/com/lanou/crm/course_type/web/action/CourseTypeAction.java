package com.lanou.crm.course_type.web.action;

import com.lanou.crm.base.action.BaseAction;
import com.lanou.crm.course_type.domain.CrmCourseType;
import com.lanou.crm.course_type.service.CourseTypeService;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ModelDriven;

import java.util.List;

/**
 * Created by zyf on 2018/1/26.
 */
public class CourseTypeAction extends BaseAction<CrmCourseType>{


	public String findAll(){

		List<CrmCourseType> allCourseTypes =
				this.getCourseTypeService().findAll();
		this.setToRootStack("allCourseTypes",allCourseTypes);

		for (CrmCourseType allCourseType : allCourseTypes) {
			System.out.println(allCourseType.getCourseName());
		}

		return "findAll";
	}


	public String findByCondition(){

		List<CrmCourseType> allCourseTypes =
				this.getCourseTypeService().findByCondition(this.getModel());

		ActionContext.getContext().put("allCourseTypes",allCourseTypes);
		return "findByCondition";
	}

	public String add(){
		this.getCourseTypeService().saveOrUpdate(this.getModel());
		return "add";
	}

	public String toAdd(){
		CrmCourseType byCondition = this.getCourseTypeService().findById(this.getModel());
		ActionContext.getContext().getValueStack().push(byCondition);
		return "toAdd";
	}



}
