package com.lanou.crm.course_type.service.impl;

import com.lanou.crm.course_type.dao.CourseTypeDao;
import com.lanou.crm.course_type.domain.CrmCourseType;
import com.lanou.crm.course_type.service.CourseTypeService;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by zyf on 2018/1/26.
 */
public class CourseTypeServiceImpl implements CourseTypeService {

	private CourseTypeDao courseTypeDao;

	public void setCourseTypeDao(CourseTypeDao courseTypeDao) {
		this.courseTypeDao = courseTypeDao;
	}

	@Override
	public List<CrmCourseType> findAll(){
		return courseTypeDao.findAll();
	}

	@Override
	public List<CrmCourseType> findByCondition(CrmCourseType model) {
		/* 拼凑条件查询语句 */
		StringBuilder sqlWhere = new StringBuilder();
		List<Object> params = new ArrayList<>();

		//isNotBlank==>过滤 null 和 " "    （空字符串或字符串只有空格)
		if (StringUtils.isNotBlank((model.getCourseName()))){
			sqlWhere.append(" and courseName like ?");
			params.add("%" +model.getCourseName()+ "%");
		}

		if (StringUtils.isNotBlank(model.getRemark())){
			sqlWhere.append(" and remark like ?");
			params.add("%" +model.getRemark()+ "%");
		}

		if (StringUtils.isNotBlank(model.getTotalStart())){
			sqlWhere.append(" and total >= ?");
			params.add(Integer.parseInt(model.getTotalStart()));
		}

		if (StringUtils.isNotBlank(model.getTotalEnd())){
			sqlWhere.append(" and total <= ?");
			params.add(Integer.parseInt(model.getTotalEnd()));
		}

		if (StringUtils.isNotBlank(model.getCourseCostStart())){
			sqlWhere.append(" and courseCost >= ?");
			params.add(Double.parseDouble(model.getCourseCostStart()));
		}

		if (StringUtils.isNotBlank(model.getCourseCostEnd())){
			sqlWhere.append(" and courseCost <= ?");
			params.add(Double.parseDouble(model.getCourseCostEnd()));
		}
		return courseTypeDao.findAll(sqlWhere.toString(),params.toArray());
	}

	@Override
	public void saveOrUpdate(CrmCourseType form) {
		courseTypeDao.saveOrUpdate(form);
	}

	@Override
	public CrmCourseType findById(CrmCourseType model) {
		return courseTypeDao.findById(model.getCourseTypeId());
	}
}
