package com.lanou.crm.course_type.service;

import com.lanou.crm.course_type.domain.CrmCourseType;

import java.util.List;

/**
 * Created by zyf on 2018/1/26.
 */
public interface CourseTypeService {
	List<CrmCourseType> findAll();

	List<CrmCourseType> findByCondition(CrmCourseType model);

	void saveOrUpdate(CrmCourseType model);

	CrmCourseType findById(CrmCourseType model);
}
