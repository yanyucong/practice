package com.lanou.crm.course_type.dao.impl;

import com.lanou.crm.base.dao.impl.BaseDaoImpl;
import com.lanou.crm.course_type.dao.CourseTypeDao;
import com.lanou.crm.course_type.domain.CrmCourseType;

/**
 * Created by zyf on 2018/1/26.
 */
public class CourseTypeDaoImpl extends BaseDaoImpl<CrmCourseType> implements CourseTypeDao {

}
