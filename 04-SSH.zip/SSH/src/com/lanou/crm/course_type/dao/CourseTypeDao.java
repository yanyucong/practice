package com.lanou.crm.course_type.dao;

import com.lanou.crm.base.dao.BaseDao;
import com.lanou.crm.course_type.domain.CrmCourseType;

import java.util.List;

/**
 * Created by zyf on 2018/1/26.
 */
public interface CourseTypeDao extends BaseDao<CrmCourseType> {
}
