package test;

import org.apache.commons.lang.StringUtils;
import org.junit.Test;

/**
 * Created by zyf on 2018/1/26.
 */
public class T {


	@Test
	public void t() throws Exception {
		String n = "";
		boolean blank = StringUtils.isBlank(n);
		System.out.println(blank);

	}
}
